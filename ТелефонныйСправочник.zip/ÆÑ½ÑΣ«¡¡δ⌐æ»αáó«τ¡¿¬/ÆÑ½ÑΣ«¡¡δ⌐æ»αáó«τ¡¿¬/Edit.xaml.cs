﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace ТелефонныйСправочник
{
    public partial class Edit : Window
    {
        public Edit()
        {
            InitializeComponent();
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
           
            try
            {
                using (var db = new user09Entities())
                { 
                    int группаКонтактов = int.Parse(group.Text);
                    var contact = new Контакты();
                    contact.Фамилия = Lastname.Text;
                    contact.Имя = Namecont.Text;
                    contact.Отчество = nameTB.Text;
                    contact.Номер_телефона = number.Text;
                    contact.E_mail = email.Text;
                    contact.Компания = Company.Text;
                    contact.Должность = Work.Text;
                    contact.ГруппаКонтактов = группаКонтактов;
                    contact.Дата_Рождения = Convert.ToDateTime(datebirth1.Text);

                    db.Контакты.Add(contact);
                    db.SaveChanges();

                }
                MessageBox.Show("Информация изменена!");
            }
            catch
            {
                MessageBox.Show("Ошибка изменения данных");

            }
        }

    }
}

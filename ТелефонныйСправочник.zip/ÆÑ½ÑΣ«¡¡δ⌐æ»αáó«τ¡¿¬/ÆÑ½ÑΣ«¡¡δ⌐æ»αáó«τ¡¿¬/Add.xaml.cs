﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Globalization;
using Microsoft.Win32;

namespace ТелефонныйСправочник
{

    public partial class Add : Window
    {
        
        public Add()
        {
            InitializeComponent();

        }
        public Add(MainWindow mainWindow)
        {
            InitializeComponent();
            if (string.IsNullOrEmpty(Lastname.Text) ||
                  string.IsNullOrEmpty(Ima.Text) ||
                  string.IsNullOrEmpty(OTCHTB.Text) ||
                  string.IsNullOrEmpty(number.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }
     

        private bool ValidatePhoneNumber(string phoneNumber)
        {
            // Пример валидации для номера телефона +7(922)654-66-99
            Regex phoneRegex = new Regex(@"^\+7\(\d{3}\)\d{3}-\d{2}-\d{2}$");
            return phoneRegex.IsMatch(phoneNumber);
        }

        private bool ValidateEmail(string email)
        {
            // Пример валидации для e-mail
            Regex emailRegex = new Regex(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,5}$");
            return emailRegex.IsMatch(email);
        }
        private void PhoneNumberTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (!ValidatePhoneNumber(textBox.Text))
            {
                MessageBox.Show("Номер телефона должен быть в формате +7(XXX)XXX-XX-XX");
            }
        }

        private void EmailTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            if (!ValidateEmail(textBox.Text))
            {
                MessageBox.Show(" Формат электронного адреса: Название(test)@" +"\n" + 
                    "Знак @ " + "\n" +
                    "Домен почтового сервера(mail)" + "\n" +
                    "Домен первого уровня(ru, от 2 до 5 букв)");
            }
        }
        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                using (var db = new user09Entities())
                {
                    var contact = new Контакты();
                    contact.Фамилия = Lastname.Text;
                    contact.Имя = Ima.Text;
                    contact.Отчество = OTCHTB.Text;
                    contact.Номер_телефона = number.Text;
                    contact.E_mail = email.Text;
                    contact.Компания = Company.Text;
                    contact.Должность = Work.Text;

                    // Получение выбранной группы контактов
                    var selectedGroup = group.SelectedItem as ГруппаКонтактов;
                    if (selectedGroup != null)
                    {
                        // Присвоение ID группы контактов свойству ГруппаКонтактов объекта contact
                        contact.ГруппаКонтактов = selectedGroup.ID_ГруппаКонтактов;
                    }

                    contact.Дата_Рождения = Convert.ToDateTime(datebirth1.Text);

                    db.Контакты.Add(contact);
                    db.SaveChanges();
                   
                    // Обновляем данные в главном окне MainWindow
                    ((MainWindow)Application.Current.MainWindow).UpdateDataGrid();
                    // Закрываем окно
                    this.Close();

                }

                MessageBox.Show("Сохранено");

            }
            catch
            {
                MessageBox.Show("Ошибка сохранения");
            }

        }

        private void Dowload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png, *.jpg, *.jpeg)|*.png;*.jpg;*.jpeg";

            if (openFileDialog.ShowDialog() == true)
            {
                string imagePath = openFileDialog.FileName;
                images.Source = new BitmapImage(new Uri(imagePath));
            }
        }
    }
}
  


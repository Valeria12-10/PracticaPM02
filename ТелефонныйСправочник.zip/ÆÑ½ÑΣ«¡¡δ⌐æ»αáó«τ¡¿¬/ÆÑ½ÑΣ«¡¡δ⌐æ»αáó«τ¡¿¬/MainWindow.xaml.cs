﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;


namespace ТелефонныйСправочник
{

    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();

        }
    
    
        public IEnumerable<dynamic> Data;

    private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            using (var db = new user09Entities())
            {
                var Data = (from r in db.Контакты
                                //join y in db.ГруппаКонтактов on r.ГруппаКонтактов equals y.ID_ГруппаКонтактов
                            select new
                            {
                                Фамилия = r.Фамилия,
                                Имя = r.Имя,
                                Отчество = r.Отчество,
                                НомерТелефона = r.Номер_телефона,
                                //Группа = y.Название

                            }).ToList();

                DGrid.ItemsSource = Data;
            
            }
        }
        public void UpdateDataGrid()
        {
            using (var db = new user09Entities())
            {
                var Data = (from r in db.Контакты
                                //   join y in db.ГруппаКонтактов on r.ГруппаКонтактов equals y.ID_ГруппаКонтактов
                              
                            select new
                            {
                                Фамилия = r.Фамилия,
                                Имя = r.Имя,
                                Отчество = r.Отчество,
                                НомерТелефона = r.Номер_телефона,
                             //   Группа = y.Название
                            }).ToList();

              
                DGrid.ItemsSource = Data;
            }
           
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            // Создаем экземпляр класса SaveFileDialog для сохранения файла
            Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();

            // Устанавливаем фильтр для файлов CSV и всех файлов
            saveFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";

            // Отображаем диалоговое окно сохранения файла
            if (saveFileDialog.ShowDialog() == true)
            {
                // Создаем экземпляр класса StreamWriter для записи в файл
                using (StreamWriter sw = new StreamWriter(saveFileDialog.FileName, false))
                {
                    // Перебираем элементы в таблице
                    foreach (var item in DGrid.Items)
                    {
                        // Получаем строку таблицы, соответствующую текущему элементу
                        DataGridRow row = (DataGridRow)DGrid.ItemContainerGenerator.ContainerFromItem(item);

                        // Получаем количество столбцов в таблице
                        int columnCount = DGrid.Columns.Count;

                        // Перебираем столбцы в строке таблицы
                        for (int i = 0; i < columnCount; i++)
                        {
                            // Если это не первый столбец, добавляем разделитель (запятую)
                            if (i > 0)
                            {
                                sw.Write(",");
                            }

                            // Получаем текст из ячейки столбца и записываем его в файл
                            sw.Write(((TextBlock)DGrid.Columns[i].GetCellContent(row)).Text);
                        }

                        // Переходим на новую строку в файле
                        sw.WriteLine();
                    }
                }
            }
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            var Add = new Add();

            Add.Show();
        }

        private void DeleteBtn_Click(object sender, RoutedEventArgs e)
        {
            // Получаем выбранный контакт из DataGrid
            var selectedContact = DGrid.SelectedItem as Контакты;

            if (selectedContact != null)
            {
                // Запрашиваем подтверждение у пользователя
                if (MessageBox.Show("Вы действительно хотите удалить запись?", "Удаление", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    user09Entities bd = new user09Entities();
                    if (DGrid.SelectedItem != null)
                    {
                        var selectedRow = DGrid.SelectedItem as dynamic;

                        // Удаляем запись из коллекции
                       Data.ToList().Remove(selectedRow);

                        // Удаляем запись из базы данных
                        bd.Контакты.Remove(bd.Контакты.Find(selectedRow.ID_контакта));

                        // Сохраняем изменения
                        bd.SaveChanges();
                    }
                    // Обновляем данные в DataGrid
                    UpdateDataGrid();

                    // Сообщение об успешном удалении
                    MessageBox.Show("Контакт удален");
                }
            }
            else
            {
                // Сообщение об ошибке, если контакт не выбран
                MessageBox.Show("Выберите контакт для удаления");
            }
           
        }

        private void BtnOutput_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new user09Entities())
            {
                var Data = (from r in db.Контакты
                            join y in db.ГруппаКонтактов on r.ГруппаКонтактов equals y.ID_ГруппаКонтактов
                            select new
                            {
                                Фамилия = r.Фамилия,
                                Имя = r.Имя,
                                Отчество = r.Отчество,
                                НомерТелефона = r.Номер_телефона,
                                Группа = y.Название

                            }).ToList();

                DGrid.ItemsSource = Data;
            }

        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchText = search.Text;

            using (var db = new user09Entities())
            {
                var Data = (from r in db.Контакты
                            join y in db.ГруппаКонтактов on r.ГруппаКонтактов equals y.ID_ГруппаКонтактов
                            where r.Фамилия.Contains(searchText) || r.Имя.Contains(searchText) || r.Отчество.Contains(searchText)
                            select new
                            {
                                Фамилия = r.Фамилия,
                                Имя = r.Имя,
                                Отчество = r.Отчество,
                                НомерТелефона = r.Номер_телефона,
                                Группа = y.Название
                            }).ToList();

                DGrid.ItemsSource = Data;
            }

            // Очищаем TextBox после поиска
            search.Text = "";
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            // Получение выбранного контакта из таблицы данных
          
            // Включаем режим редактирования
            DGrid.IsReadOnly = false;
            UpdateDataGrid();
            // Открытие окна редактирования и передача выбранного контакта
            //Edit editWindow = new Edit(контакт);
            // editWindow.ShowDialog();

            // Обновление таблицы данных после редактирования контакта
            DGrid.ItemsSource = null;
            using (var db = new user09Entities())
            {
                DGrid.ItemsSource = db.Контакты.ToList();
            }

        }

        private void Search(object sender, TextChangedEventArgs e)
        {
            
        }
    }
}
